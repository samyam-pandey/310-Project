<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "deliverme";

$sql = mysqli_connect($host, $username, $password, $database) or die('could not connect');

?>